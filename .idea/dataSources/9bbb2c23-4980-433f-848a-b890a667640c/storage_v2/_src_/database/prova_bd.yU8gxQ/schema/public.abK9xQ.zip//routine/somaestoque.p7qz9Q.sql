create function somaestoque() returns numeric
    language sql
as
$$
SELECT SUM(estoque) FROM Produto

$$;

alter function somaestoque() owner to postgres;

