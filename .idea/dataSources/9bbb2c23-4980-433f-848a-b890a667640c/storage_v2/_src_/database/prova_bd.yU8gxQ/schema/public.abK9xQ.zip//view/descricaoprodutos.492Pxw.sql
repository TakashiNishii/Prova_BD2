create view descricaoprodutos(descrprod) as
SELECT produto.descrprod
FROM produto
ORDER BY produto.descrprod;

alter table descricaoprodutos
    owner to postgres;

