create function historico_log_function() returns trigger
    language plpgsql
as
$$
BEGIN

INSERT INTO historico_log (data, alteracao, codprod, descrprod, valorantigo, valornovo)

VALUES (NOW(), 'Insert', new.CodProd, new.DescrProd, 0, new.PrecoProd);

RETURN NEW;

END

$$;

alter function historico_log_function() owner to postgres;

