create view visaoprodutotipo(codprod, descrprod, precoprod, descrtipoprod) as
SELECT prd.codprod,
       prd.descrprod,
       prd.precoprod,
       tdp.descrtipoprod
FROM produto prd
         JOIN tipodeproduto tdp ON tdp.codtipoprod = prd.codtipoprod;

alter table visaoprodutotipo
    owner to postgres;

